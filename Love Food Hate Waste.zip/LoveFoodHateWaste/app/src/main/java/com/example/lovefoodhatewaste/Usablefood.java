package com.example.lovefoodhatewaste;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class Usablefood extends AppCompatActivity {

    RelativeLayout Restaurants, Functions, Others;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usablefood);
        Restaurants = findViewById(R.id.restaurants);
        Functions = findViewById(R.id.functions);
        Others = findViewById(R.id.other);


        Restaurants.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Usablefood.this, Restaurants.class);
                startActivity(intent);

            }
        });
        Functions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Usablefood.this, Functions.class);
                startActivity(intent);

            }
        });
        Others.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(Usablefood.this, Others.class);
            startActivity(intent);

        }
    });
    }
}