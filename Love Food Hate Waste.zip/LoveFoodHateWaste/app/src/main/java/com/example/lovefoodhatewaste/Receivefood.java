package com.example.lovefoodhatewaste;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class Receivefood extends AppCompatActivity {

    RelativeLayout Usablefood2,Unusablefood2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receivefood);
        Usablefood2 = findViewById(R.id.receivefood);
        Unusablefood2= findViewById(R.id.Unusablefood);
        Usablefood2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Receivefood.this, Usablefood2.class);
                startActivity(intent);

            }
        });
        Unusablefood2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Receivefood.this, Unusablefood2.class);
                startActivity(intent);

            }
        });
    }
}