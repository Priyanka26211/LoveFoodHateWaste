package com.example.lovefoodhatewaste;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class Unusablefood extends AppCompatActivity {

    RelativeLayout Markets,Others2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unusablefood);
        Markets = findViewById(R.id.markets);
        Others2 = findViewById(R.id.other);
        Markets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Unusablefood.this, Markets.class);
                startActivity(intent);

            }
        });
        Others2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Unusablefood.this, Others2.class);
                startActivity(intent);

            }
        });
    }
}