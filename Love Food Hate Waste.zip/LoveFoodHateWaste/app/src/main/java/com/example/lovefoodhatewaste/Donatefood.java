package com.example.lovefoodhatewaste;

import static com.example.lovefoodhatewaste.R.*;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class Donatefood extends AppCompatActivity {
    RelativeLayout Usablefood, Unusablefood;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donatefood);
        Usablefood = findViewById(R.id.donatefood);
        Unusablefood = findViewById(R.id.Unusablefood);
        Usablefood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Donatefood.this, Usablefood.class);
                startActivity(intent);

            }
        });
        Unusablefood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Donatefood.this, Unusablefood.class);
                startActivity(intent);

            }
        });
    }
}
