package com.example.lovefoodhatewaste;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class  Usablefood2 extends AppCompatActivity {
    RelativeLayout AkshayPatraFoundation, Feedingformfar, GiveIndia, KhushiyaanFoundation;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usablefood2);
        AkshayPatraFoundation=findViewById(R.id.AkshayPatraFoundation);
        Feedingformfar=findViewById(R.id.Feedingformfar);
        GiveIndia=findViewById(R.id.GiveIndia);
        KhushiyaanFoundation =findViewById(R.id.KhushiyaanFoundation);
        AkshayPatraFoundation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Usablefood2.this, AkshayPatraFoundation.class);
                    startActivity(intent);

                }
            });
        Feedingformfar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Usablefood2.this, Feedingformfar.class);
                    startActivity(intent);

                }
            });
        GiveIndia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Usablefood2.this, GiveIndia.class);
                startActivity(intent);

            }
        });
        KhushiyaanFoundation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Usablefood2.this, KhushiyaanFoundation.class);
                startActivity(intent);

            }
        });
    }
}