package com.example.lovefoodhatewaste;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

public class Unusablefood2 extends AppCompatActivity {

    RelativeLayout GetGreenBioEnergy, BharatBiogasEnergyLimited, FRDBIOMECH, IndianBiogasAssociation;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_unusablefood2);
        GetGreenBioEnergy = findViewById(R.id.GetGreenBioEnergy);
        BharatBiogasEnergyLimited = findViewById(R.id.BharatBiogasEnergyLimited);
        FRDBIOMECH = findViewById(R.id.FRDBIOMECH);
        IndianBiogasAssociation = findViewById(R.id.IndianBiogasAssociation);
        GetGreenBioEnergy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Unusablefood2.this, GetGreenBioEnergy.class);
                startActivity(intent);

            }
        });
        BharatBiogasEnergyLimited.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Unusablefood2.this, BharatBiogasEnergyLimited.class);
                startActivity(intent);

            }
        });
        FRDBIOMECH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Unusablefood2.this, FRDBIOMECH.class);
                startActivity(intent);

            }
        });
        IndianBiogasAssociation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Unusablefood2.this, IndianBiogasAssociation.class);
                startActivity(intent);

            }
        });
    }
}